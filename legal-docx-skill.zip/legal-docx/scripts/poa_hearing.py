# -*- coding: utf-8 -*-
"""ייפוי כוח לייצוג בשימוע / בוועדה – הנוסח הקצר והרגיל של המשרד.

    python poa_hearing.py "רן כהן" 036519874 'פאלו אלטו נטוורקס בע"מ' out.docx
    python poa_hearing.py "רחל מיראי" 207088162 'בנק לאומי לישראל בע"מ' out.docx f

🔴 לשון (25.11.2026): הארגומנט החמישי הוא מין הלקוח – m (ברירת מחדל) או f.
   ללקוחה (f) אישור עוה"ד נכתב "הופיעה בפניי מרשתי הנ"ל ... וחתמה".
   תמיד לבדוק את מין הלקוח (ת.ז. / מכתב הזימון) ולהעביר f כשמדובר באישה.

ממלא את assets/poa-hearing-template.docx (נייר הפירמה, 3 סעיפים,
מ.ר. 21227) ומטמיע את חתימת סיגל על שורת "חתימה" באישור עוה"ד.

🔴 תאריכים (הנחיית סיגל, 28.10.2026 – אחרי שמשרד החינוך החזיר ייפוי כוח
שבו אישור עוה"ד היה מתוארך לפני חתימת הלקוחה):
  • אין שורת תאריך בחלק שהלקוח חותם.
  • התאריך מופיע רק באישור עוה"ד: "מאשרת בזה כי ביום ____________ הופיע
    בפניי מרשי הנ"ל ... וחתם על ייפוי כוח זה" – והוא נשאר ריק. לא ממלאים
    בו תאריך (גם לא את תאריך הבקשה).
  • לפני שליחה ללקוח לחתימה – מעבירים לסיגל לאישור.
ההיסטים של החתימה כוילו ב-PDF – לוודא חזותית בכל זאת.
"""
import os, sys, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, '..', 'assets')
ANCHOR = '<w:t xml:space="preserve">חתימה: ________________</w:t></w:r>'


FEMININE = [('הופיע בפניי מרשי', 'הופיעה בפניי מרשתי'), ('וחתם על', 'וחתמה על')]


def build(name, id_no, company, out, gender='m', v=-1400000, h=2300000):
    tpl = os.path.join(ASSETS, 'poa-hearing-template.docx')
    z = zipfile.ZipFile(tpl)
    doc = z.read('word/document.xml').decode('utf-8')
    doc = (doc.replace('{{NAME}}', name).replace('{{ID}}', id_no)
              .replace('{{COMPANY}}', company))
    if gender == 'f':
        for a, b in FEMININE:
            assert a in doc, a
            doc = doc.replace(a, b)
    sig = open(os.path.join(ASSETS, 'signature-drawing.xml'), encoding='utf-8').read()
    sig = (sig.replace('<wp:posOffset>218578</wp:posOffset>', '<wp:posOffset>%d</wp:posOffset>' % v)
              .replace('<wp:posOffset>469265</wp:posOffset>', '<wp:posOffset>%d</wp:posOffset>' % h))
    # שורת ה"חתימה" השנייה היא של עוה"ד – מעגנים בה את החתימה הסרוקה
    i = doc.rindex(ANCHOR)
    j = doc.rfind('<w:p>', 0, i)
    k = doc.index('</w:pPr>', j) + len('</w:pPr>')
    doc = doc[:k] + sig + doc[k:]
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as zo:
        for it in z.infolist():
            zo.writestr(it, doc if it.filename == 'word/document.xml' else z.read(it.filename))
    return out


if __name__ == '__main__':
    build(*sys.argv[1:6])
