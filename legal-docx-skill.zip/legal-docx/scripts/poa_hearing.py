# -*- coding: utf-8 -*-
"""ייפוי כוח – הנוסח הקצר והרגיל של המשרד (שימוע, וגם עניינים אחרים).

    python poa_hearing.py "רן כהן" 036519874 'פאלו אלטו נטוורקס בע"מ' out.docx [25.10.2026]
    python poa_hearing.py "מארק כהן" 012345678 "" out.docx 16.11.2026 \
        --clause "לייצגני בכל עניין הנוגע לתקופת עבודתי במלונות דן פנורמה, לרבות העסקתי שם, סיומה וכל זכות הנובעת ממנה."
    python poa_hearing.py "דנה לוי" 012345678 'חברה בע"מ' out.docx 16.11.2026 --female

ממלא את assets/poa-hearing-template.docx (נייר הפירמה, 3 סעיפים,
מ.ר. 21227) ומטמיע את חתימת סיגל באישור עוה"ד.

🔴 תאריכים (הנחיות סיגל 25.10.2026 ו-16.11.2026):
- בחתימת סיגל (אישור עוה"ד) ממלאים את התאריך שבו התבקש ייפוי הכוח
  (ברירת מחדל: היום, dd.mm.yyyy).
- בחלק של הלקוח **אין שורת תאריך בכלל** – רק קו חתימה ושם הלקוח. לא
  להוסיף "תאריך:" ולא "חתימה:" ליד קו החתימה של הלקוח. אחרת יוצא
  שהלקוח חתם אחרי התאריך שבו סיגל אימתה את חתימתו.

--clause  מחליף את סעיף 1 (לייצוג שאינו שימוע). אז COMPANY לא נדרש.
--female  לשון נקבה באישור עוה"ד ("מרשתי").
ההיסטים של החתימה (v=-670000, h=1100000 EMU) כוילו ב-PDF – לוודא חזותית.
"""
import argparse, datetime, os, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, '..', 'assets')
DATE_LINE = 'תאריך: ________________'
ANCHOR = '<w:t xml:space="preserve">אני הח"מ, מאשרת בזה את חתימת מרשי הנ"ל.</w:t></w:r>'
CLAUSE1 = 'לייצגני בהליך השימוע שנערך לי על ידי חברת {{COMPANY}}, ובכל עניין הנוגע להעסקתי בה ולסיומה.'


def build(name, id_no, company, out, date=None, clause=None, female=False,
          v=-670000, h=1100000):
    date = date or datetime.date.today().strftime('%d.%m.%Y')
    tpl = os.path.join(ASSETS, 'poa-hearing-template.docx')
    z = zipfile.ZipFile(tpl)
    doc = z.read('word/document.xml').decode('utf-8')
    if clause:
        assert CLAUSE1 in doc
        doc = doc.replace(CLAUSE1, clause)
    doc = (doc.replace('{{NAME}}', name).replace('{{ID}}', id_no)
              .replace('{{COMPANY}}', company or ''))
    # בתבנית יש שורת תאריך אחת בלבד – של עוה"ד. ממלאים אותה בתאריך הבקשה.
    assert doc.count(DATE_LINE) == 1, 'לקוח לא אמור לקבל שורת תאריך'
    doc = doc.replace(DATE_LINE, 'תאריך: ' + date)
    sig = open(os.path.join(ASSETS, 'signature-drawing.xml'), encoding='utf-8').read()
    sig = (sig.replace('<wp:posOffset>218578</wp:posOffset>', '<wp:posOffset>%d</wp:posOffset>' % v)
              .replace('<wp:posOffset>469265</wp:posOffset>', '<wp:posOffset>%d</wp:posOffset>' % h))
    i = doc.index(ANCHOR)
    j = doc.rfind('<w:r>', 0, i)
    doc = doc[:j] + sig + doc[j:]
    if female:
        doc = doc.replace('חתימת מרשי הנ"ל', 'חתימת מרשתי הנ"ל')
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as zo:
        for it in z.infolist():
            zo.writestr(it, doc if it.filename == 'word/document.xml' else z.read(it.filename))
    return out


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('name'); ap.add_argument('id_no'); ap.add_argument('company')
    ap.add_argument('out'); ap.add_argument('date', nargs='?')
    ap.add_argument('--clause'); ap.add_argument('--female', action='store_true')
    a = ap.parse_args()
    build(a.name, a.id_no, a.company, a.out, a.date, a.clause, a.female)
