# -*- coding: utf-8 -*-
"""ייפוי כוח לייצוג בשימוע – הנוסח הקצר והרגיל של המשרד.

    python poa_hearing.py "רן כהן" 036519874 'פאלו אלטו נטוורקס בע"מ' out.docx

ממלא את assets/poa-hearing-template.docx (נייר הפירמה, 3 סעיפים,
מ.ר. 21227) ומטמיע את חתימת סיגל על שורת "חתימה" באישור עוה"ד.
ההיסטים (v=-670000, h=1100000 EMU) כוילו ב-PDF – לוודא חזותית בכל זאת.
"""
import os, sys, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, '..', 'assets')
ANCHOR = '<w:t xml:space="preserve">אני הח"מ, מאשרת בזה את חתימת מרשי הנ"ל.</w:t></w:r>'


def build(name, id_no, company, out, v=-670000, h=1100000):
    tpl = os.path.join(ASSETS, 'poa-hearing-template.docx')
    z = zipfile.ZipFile(tpl)
    doc = z.read('word/document.xml').decode('utf-8')
    doc = (doc.replace('{{NAME}}', name).replace('{{ID}}', id_no)
              .replace('{{COMPANY}}', company))
    sig = open(os.path.join(ASSETS, 'signature-drawing.xml'), encoding='utf-8').read()
    sig = (sig.replace('<wp:posOffset>218578</wp:posOffset>', '<wp:posOffset>%d</wp:posOffset>' % v)
              .replace('<wp:posOffset>469265</wp:posOffset>', '<wp:posOffset>%d</wp:posOffset>' % h))
    i = doc.index(ANCHOR)
    j = doc.rfind('<w:r>', 0, i)
    doc = doc[:j] + sig + doc[j:]
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as zo:
        for it in z.infolist():
            zo.writestr(it, doc if it.filename == 'word/document.xml' else z.read(it.filename))
    return out


if __name__ == '__main__':
    build(*sys.argv[1:5])
