# -*- coding: utf-8 -*-
"""
בונה מכתב על נייר הפירמה של משרד עו"ד סיגל הורוביץ (Sigalaw).

התבנית assets/sigalaw-letterhead.docx כוללת:
  • header2.xml  → הלוגו של המשרד (word/media/image2.jpeg)
  • footer2.xml  → פרטי הקשר בתחתית העמוד
  • word/media/image1.emf → החתימה הסרוקה של סיגל (floating anchor)
  • שוליים: top=2836, right=1133, bottom=426, left=1418 (רוחב תוכן 9355)
  • numId 6 / ilvl 1 → תבליטים (bullets)

שימוש:
    from sigalaw_letter import Letter
    L = Letter('assets/sigalaw-letterhead.docx')
    L.date('‏26 אוגוסט 2026')
    L.blank()
    L.para('לכבוד')
    L.para("גב' אורית רוט", ul=True)
    L.subject('הסכם שכר טרחה – ', 'עריכת הסכם התקשרות למתן שירותים')
    L.para('...')
    L.bullets(['הערה ראשונה', 'הערה שנייה'], signature_on_last=True)
    L.signoff()
    L.confirm_block()      # אני מאשר/ת ... שם / תאריך / חתימה
    L.save('out.docx')

כללי RTL קריטיים (ראו SKILL.md): bidi ברמת ה-section, w:jc=both/right/center,
ו-<w:rtl/> בכל run. אין להשתמש ב-LEFT/RIGHT למספור.
"""
import os
import re
import shutil
import zipfile

CONTENT_WIDTH = 11906 - 1133 - 1418  # 9355 twips

PPR_END = ('<w:rPr><w:rFonts w:cs="David"/><w:sz w:val="24"/>'
           '<w:szCs w:val="24"/><w:rtl/></w:rPr>')


def esc(t):
    return t.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def rpr(bold=False, ul=False, size=24):
    s = '<w:rPr><w:rFonts w:cs="David" w:hint="cs"/>'
    if bold:
        s += '<w:b/><w:bCs/>'
    s += '<w:sz w:val="%d"/><w:szCs w:val="%d"/>' % (size, size)
    if ul:
        # ul='thick' → קו תחתי מודגש (שורת "הנדון")
        s += '<w:u w:val="%s"/>' % ('thick' if ul == 'thick' else 'single')
    s += '<w:rtl/></w:rPr>'
    return s


def run(text, bold=False, ul=False, size=24):
    return ('<w:r>' + rpr(bold, ul, size) +
            '<w:t xml:space="preserve">' + esc(text) + '</w:t></w:r>')


def tabs(n):
    return ''.join('<w:r>' + rpr() + '<w:tab/></w:r>' for _ in range(n))


class Letter:
    def __init__(self, template_path):
        self.template = template_path
        with zipfile.ZipFile(template_path) as z:
            doc = z.read('word/document.xml').decode('utf-8')
        self.head = doc[:doc.find('<w:body>') + len('<w:body>')]
        self.sect = doc[doc.rfind('<w:sectPr'):]
        m = re.search(r'<w:r[^>]*><w:rPr><w:noProof/></w:rPr><w:drawing>'
                      r'.*?</w:drawing></w:r>', doc, re.S)
        if m:
            self.sig_run = m.group(0)
        else:
            # התבנית הריקה לא מכילה את החתימה בגוף המסמך – טוענים אותה
            # מ-assets/signature-drawing.xml (ה-relationship rId8 ותמונת
            # image1.emf כבר קיימים בתוך התבנית).
            sig = os.path.join(os.path.dirname(os.path.abspath(template_path)),
                               'signature-drawing.xml')
            self.sig_run = (open(sig, encoding='utf-8').read()
                            if os.path.exists(sig) else None)
        self.body = []

    # ---- building blocks ---------------------------------------------------
    def _p(self, runs_xml, jc='both', contextual=True):
        ppr = '<w:pPr><w:spacing w:after="0" w:line="280" w:lineRule="atLeast"/>'
        if contextual:
            ppr += '<w:contextualSpacing/>'
        ppr += '<w:jc w:val="%s"/>' % jc + PPR_END + '</w:pPr>'
        self.body.append('<w:p>' + ppr + runs_xml + '</w:p>')

    def blank(self, n=1):
        for _ in range(n):
            self._p('')

    def date(self, text):
        """התאריך מופיע בפינה השמאלית העליונה, כמו בכל מכתבי המשרד.
        חשוב: טקסט קבוע ולא שדה DATE – שדה מתעדכן בכל פתיחה של הקובץ."""
        self._p(run(text), jc='right')

    def para(self, text, bold=False, ul=False, jc='both', contextual=False):
        self._p(run(text, bold, ul), jc=jc, contextual=contextual)

    def heading(self, text):
        """כותרת משנה בגוף המכתב: מודגשת + קו תחתי, ואחריה נקודתיים."""
        self._p(run(text, bold=True, ul=True) + run(':', bold=True))

    def subject(self, prefix, underlined):
        """שורת 'הנדון:' – ממורכזת, מודגשת, עם קו תחתי **מודגש** (thick)
        לאורך כל השורה, כולל המילה 'הנדון:' עצמה."""
        runs = (run('הנדון:', bold=True, ul='thick') +
                '<w:r>' + rpr(True, 'thick') + '<w:tab/></w:r>' +
                run(prefix + underlined, bold=True, ul='thick'))
        ppr = ('<w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/>'
               '<w:ind w:left="-57"/><w:contextualSpacing/><w:jc w:val="center"/>'
               + PPR_END + '</w:pPr>')
        self.body.append('<w:p>' + ppr + runs + '</w:p>')

    def bullets(self, items, signature_on_last=False, sig_offset=None):
        """items: רשימת מחרוזות, או רשימת [(טקסט, bold, underline), ...].

        signature_on_last מעגן את תמונת החתימה לפסקה האחרונה. ההיסט האנכי
        נמדד מראש הפסקה: יש לקזז כ-355600 EMU (שתי שורות) על כל שורה שהפסקה
        האחרונה קצרה ממה שתוכנן. ברירת מחדל -137022 מתאימה לפסקה בת 3 שורות
        שאחריה 2 פסקאות ריקות ואז 'בכבוד רב,'."""
        off = -137022 if sig_offset is None else sig_offset
        ppr = ('<w:pPr><w:numPr><w:ilvl w:val="1"/><w:numId w:val="6"/></w:numPr>'
               '<w:spacing w:after="0" w:line="276" w:lineRule="auto"/>'
               '<w:contextualSpacing/><w:jc w:val="both"/>' + PPR_END + '</w:pPr>')
        for i, item in enumerate(items):
            parts = [(item, False, False)] if isinstance(item, str) else item
            runs = ''
            if signature_on_last and i == len(items) - 1 and self.sig_run:
                runs += re.sub(r'<wp:posOffset>218578</wp:posOffset>',
                               '<wp:posOffset>%d</wp:posOffset>' % off,
                               self.sig_run)
            runs += ''.join(run(t, b, u) for (t, b, u) in parts)
            self.body.append('<w:p>' + ppr + runs + '</w:p>')

    def table(self, rows, widths, header=True, shade='EFEBE4'):
        """טבלת RTL. rows: רשימת רשימות מחרוזות. widths חייב להסתכם ל-9355."""
        brd = '<w:{s} w:val="single" w:sz="6" w:space="0" w:color="808080"/>'
        borders = ('<w:tcBorders>' + ''.join(brd.format(s=s) for s in
                   ('top', 'start', 'bottom', 'end')) + '</w:tcBorders>')
        out = []
        for r, cells in enumerate(rows):
            tcs = []
            bold = (header and r == 0) or r == len(rows) - 1
            fill = shade if bold else None
            for c, (text, w) in enumerate(zip(cells, widths)):
                tcpr = '<w:tcPr><w:tcW w:w="%d" w:type="dxa"/>' % w + borders
                if fill:
                    tcpr += ('<w:shd w:val="clear" w:color="auto" w:fill="%s"/>'
                             % fill)
                tcpr += '<w:vAlign w:val="center"/></w:tcPr>'
                jc = 'start' if c == 0 else 'center'
                ppr = ('<w:pPr><w:spacing w:before="60" w:after="60" '
                       'w:line="280" w:lineRule="atLeast"/><w:jc w:val="%s"/>'
                       % jc + PPR_END + '</w:pPr>')
                tcs.append('<w:tc>' + tcpr + '<w:p>' + ppr +
                           run(text, bold) + '</w:p></w:tc>')
            out.append('<w:tr>' + ''.join(tcs) + '</w:tr>')
        grid = ''.join('<w:gridCol w:w="%d"/>' % w for w in widths)
        self.body.append(
            '<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:bidiVisual/>'
            '<w:tblW w:w="%d" w:type="dxa"/><w:tblLayout w:type="fixed"/>'
            '<w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" '
            'w:firstColumn="1" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/>'
            '</w:tblPr><w:tblGrid>%s</w:tblGrid>%s</w:tbl>'
            % (CONTENT_WIDTH, grid, ''.join(out)))

    def signoff(self, name='סיגל הורוביץ, עו"ד', lead_blanks=2):
        """'בכבוד רב,' + שם – מוזחים שמאלה ב-7 טאבים, כמו בכל מכתבי המשרד.
        החתימה עצמה היא תמונה צפה שעוגנה קודם לכן ב-bullets(...)."""
        self.blank(lead_blanks)
        self._p(tabs(7) + run('בכבוד רב,'), contextual=False)
        self.blank()
        self._p(tabs(7) + run(name), contextual=False)

    def confirm_block(self, text='אני מאשרת את הסכם שכר הטרחה.', gap=2):
        """בלוק אישור הלקוח. בין שורות שם / תאריך / חתימה – 2 שורות רווח
        (הנחיית סיגל, 26.10.2026), כדי שיהיה מקום לכתוב ולחתום ביד."""
        self.blank()
        self._p(run(text), contextual=False)
        for i, label in enumerate(('שם', 'תאריך', 'חתימה')):
            if i:
                self.blank(gap)
            self._p(run('%s: _____________' % label), contextual=False)

    # ---- output ------------------------------------------------------------
    WATERMARK_RE = re.compile(
        r'<w:sdt>(?:(?!</w:sdt>).)*?docPartGallery w:val="Watermarks".*?</w:sdt>',
        re.S)

    def _strip_watermarks(self, workdir):
        """מסיר סימני מים ("טיוטה" וכו') מכל ה-headers/footers.

        מסמכים היוצאים ללקוח לעולם אינם נושאים סימן מים. התבנית עלולה
        לחזור ולכלול אותו אם היא תוחלף, ולכן ההסרה מתבצעת בכל שמירה."""
        wd = os.path.join(workdir, 'word')
        for fn in os.listdir(wd):
            if not fn.endswith('.xml'):
                continue
            if not (fn.startswith('header') or fn.startswith('footer')):
                continue
            full = os.path.join(wd, fn)
            with open(full, encoding='utf-8') as f:
                xml = f.read()
            if 'Watermarks' not in xml:
                continue
            with open(full, 'w', encoding='utf-8') as f:
                f.write(self.WATERMARK_RE.sub('', xml))

    def save(self, path, workdir=None):
        workdir = workdir or (path + '.tmp')
        if os.path.isdir(workdir):
            shutil.rmtree(workdir)
        os.makedirs(workdir)
        with zipfile.ZipFile(self.template) as z:
            z.extractall(workdir)
        with open(os.path.join(workdir, 'word', 'document.xml'), 'w',
                  encoding='utf-8') as f:
            f.write(self.head + ''.join(self.body) + self.sect)
        self._strip_watermarks(workdir)
        if os.path.exists(path):
            os.remove(path)
        with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
            for root, _, files in os.walk(workdir):
                for fn in files:
                    full = os.path.join(root, fn)
                    z.write(full, os.path.relpath(full, workdir))
        shutil.rmtree(workdir)
        return path
